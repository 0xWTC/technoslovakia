# -*- coding: utf-8 -*- 
#python 3.5.2

import http.server
import io
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree

from config import HOST_NAME, PORT_NUMBER, filtercfg, SEND_ERROR_NOT_SUPPORTED
from traceback import format_tb


class AtomRssProcessor:
    def __init__(self, url, feedxml):
        self._url = url
        self._feedxml = feedxml
        self._nsdict = None

    def process(self, charset='UTF-8'):
        print(filtercfg)
        feedtree = xml.etree.ElementTree.parse(io.BytesIO(self._feedxml))
        feed = feedtree.getroot()

        ns = self.get_namespace(feed)
        xml.etree.ElementTree.register_namespace('', ns)
        self._nsdict = {'xmlns': ns}
        has_subs = False

        # xml.etree.ElementTree.dump(feed)  # dump original feed

        for site, cfg in filtercfg.items():
            if 'sub' in cfg:
                has_subs = True
            if urllib.parse.urlsplit(self._url).netloc.endswith(site.strip()):
                for entry in feed.findall('xmlns:entry', self._nsdict):
                    if 'reddit' in site:  # TODO: site specific pre parsers
                        from html import unescape
                        true_link = self.get_reddit_true_link(unescape(entry.find('xmlns:content', self._nsdict).text))
                        entry.find('xmlns:link', self._nsdict).set('href', true_link)

                    link = entry.find('xmlns:link' , self._nsdict).get('href')
                    link_domain = urllib.parse.urlsplit(link).netloc.split(':')[0]
                    title = entry.find('xmlns:title' , self._nsdict).text

                    if self.endswith_keyword(link_domain, cfg['url_filter']):
                        #print('removing entry due to site URL filter in:', site, link)
                        feed.remove(entry)
                        continue
                    if self.contains_keyword(title, cfg['title_filter']):
                        #print('removing entry due to site TITLE filter in:', site, title)
                        feed.remove(entry)
                        continue

                    if has_subs:
                        for sub, subfilters in cfg['sub'].items():
                            if entry.find('xmlns:category', self._nsdict).get('term') == sub:
                                if self.endswith_keyword(link_domain, subfilters['url_filter']):
                                    #print('removing entry due to category URL filter in:', site+':'+sub, link)
                                    feed.remove(entry)
                                    break
                                if self.contains_keyword(title, subfilters['title_filter']):
                                    #print('removing entry due to category TITLE filter in:', site+':'+sub, title)
                                    feed.remove(entry)
                                    break

        buf = io.BytesIO()
        feedtree.write(buf, encoding=charset, xml_declaration=True)
        return buf.getvalue()

    @staticmethod
    def contains_keyword(elem_text, keywords):
        for k in keywords:
            if k in elem_text:
                # print(elem_text, 'contains', k.strip())
                return True
        else:
            return False

    @staticmethod
    def endswith_keyword(elem_text, keywords):
        for k in keywords:
            if elem_text.endswith(k.strip()):
                # print(elem_text, 'ends with', k.strip())
                return True
        else:
            return False

    @staticmethod
    def get_namespace(element):
        m = re.match(r'\{(.*)\}', element.tag)
        return m.group(1) if m else ''

    @staticmethod
    def get_reddit_true_link(rsscont):
        m = re.search(r'href=[\"]?([^\">]+)[\">]+\[link\]', rsscont)
        return m.group(1)


class RSSRequestHandler(http.server.BaseHTTPRequestHandler):
    def do_HEAD(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()

    def do_GET(self):
        """Respond to a GET request."""

        resp_code = 200
        resp_msg = None
        resp_headers = [('Content-type', 'text/html')]
        resp_content = b''

        send_error = False
        error_code = 400
        error_info = 'Parameter incorrect: Recieved path is not correct url!'
        param = urllib.parse.unquote(self.path.strip('/'))
        if self.is_valid_url(param):

            resp = None
            try:
                resp = urllib.request.urlopen(urllib.request.Request(param, headers={
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
                                  'Chrome/53.0.2785.116 Safari/537.36'}))
            except urllib.error.HTTPError as e:
                resp_code = e.code
                resp_msg = e.reason
                resp_headers = e.headers.items()
                resp_content = e.read()
            except Exception as e:
                send_error = True
                error_code = 503
                from html import escape
                error_info = str(e)

            else:
                resp_code = resp.status
                resp_msg = resp.reason
                orig_headers = resp.getheaders()
                orig_content = resp.read()
                rssc = self.get_rss_class(orig_headers)
                if rssc:
                    try:
                        resp_headers, resp_content = self.transform_rss_content(rssc, orig_headers, orig_content, param)
                    except Exception as e:
                        send_error = True
                        error_code = 500
                        error_info = str(e) + '\n\n' + ''.join(format_tb(e.__traceback__))

                else:
                    if SEND_ERROR_NOT_SUPPORTED:
                        send_error = True
                        error_code = 501
                        error_info = 'Requested site contains unsupported content'
                    else:
                        resp_headers = orig_headers
                        resp_content = orig_content
            finally:
                if resp:
                    resp.close()

        else:
            send_error = True
            error_code = 400
            error_info = 'Parameter incorrect: Recieved path is not correct url!'

        if send_error:
            self.send_error(error_code, explain=error_info)
        else:
            self.send_response(resp_code, message=resp_msg)
            for h in resp_headers:
                self.send_header(*h)
            self.end_headers()
            self.wfile.write(resp_content)

    @staticmethod
    def is_valid_url(url):
        import re
        regex = re.compile(
            r'^https?://'  # http:// or https://
            r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|'  # domain...
            r'localhost|'  # localhost...
            r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # ...or ip
            r'(?::\d+)?'  # optional port
            r'(?:/?|[/?]\S+)$', re.IGNORECASE)
        return url is not None and regex.search(url)

    # @staticmethod
    # def is_rss_content(headers):
    #     for h in headers:
    #         if h[0] == 'Content-Type':
    #             return 'application/atom+xml' in h[1]
    #     return False

    @staticmethod
    def get_rss_class(headers):
        for h in headers:
            if h[0] == 'Content-Type':
                if 'application/atom+xml' in h[1]:
                    return AtomRssProcessor
        return None

    @staticmethod
    def transform_rss_content(rss_processor, orig_headers, orig_content, url):
        charset = 'ISO-8859-1'
        for h in orig_headers:
            if h[0] == 'Content-Type':
                if ';' in h[1]:
                    charset = h[1].split(';')[1].split('=')[1]
                    break

        transformed_content = (rss_processor(url, orig_content).process(charset))

        headers = orig_headers
        for i, h in enumerate(headers):
            if h[0] == 'Content-Length':
                headers[i] = (h[0], str(len(transformed_content)))
                break
        return headers, transformed_content


def run(server_class=http.server.HTTPServer, handler_class=RSSRequestHandler):
    httpd = server_class((HOST_NAME, PORT_NUMBER), handler_class)
    print(time.asctime(), 'Server Starts - %s:%s' % (HOST_NAME, PORT_NUMBER))
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    httpd.server_close()
    print(time.asctime(), 'Server Stops - %s:%s' % (HOST_NAME, PORT_NUMBER))


if __name__ == '__main__':
    run()
