import csv

HOST_NAME = 'localhost'
PORT_NUMBER = 8000
filtercfg = None
SEND_ERROR_NOT_SUPPORTED = True


def read_config() -> dict:
    config = {}
    with open('config.csv', newline='') as confcsv:
        dialect = csv.Sniffer().sniff(confcsv.read())
        confcsv.seek(0)
        reader = csv.reader(confcsv, dialect)
        next(reader)  # skip header
        paramdelim = ';'
        if dialect.delimiter is paramdelim:
            paramdelim = ','
        for row in reader:
            site = row[0].strip()
            config[site] = {}
            config[site]['title_filter'] = [p.strip() for p in row[1].split(paramdelim) if p.strip()]
            config[site]['url_filter'] = [p.strip() for p in row[2].split(paramdelim) if p.strip()]

            if row[3]:
                subdict = {}
                with open(row[3], newline='') as subcsv:
                    dialect = csv.Sniffer().sniff(subcsv.read())
                    subcsv.seek(0)
                    subreader = csv.reader(subcsv, dialect)
                    next(subreader)  # skip header
                    subdelim = ';'
                    if dialect.delimiter is subdelim:
                        subdelim = ','
                    for subrow in subreader:
                        sub = subrow[0].strip()
                        subdict[sub] = {}
                        subdict[sub]['title_filter'] = [p.strip() for p in subrow[1].split(subdelim) if p.strip()]
                        subdict[sub]['url_filter'] = [p.strip() for p in subrow[2].split(subdelim) if p.strip()]

                splitsubdict = {}
                for k, v in subdict.items():
                    for sk in [skey.strip() for skey in k.split(subdelim) if skey.strip()]:
                        if sk in splitsubdict:
                            splitsubdict[sk]['title_filter'].extend(v['title_filter'])
                            splitsubdict[sk]['url_filter'].extend(v['url_filter'])
                        else:
                            splitsubdict[sk] = {}
                            splitsubdict[sk]['title_filter'] = v['title_filter'].copy()
                            splitsubdict[sk]['url_filter'] = v['url_filter'].copy()

                config[row[0]]['sub'] = splitsubdict
    return config


if filtercfg is None:
    filtercfg = read_config()
# print(filtercfg)
